var secretKey = 'pleaseWork'
module.exports = secretKey;
